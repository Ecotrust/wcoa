from django.apps import AppConfig


class WcoaConfig(AppConfig):
    name = 'wcoa'
